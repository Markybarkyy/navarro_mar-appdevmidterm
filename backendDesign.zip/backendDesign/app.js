const express = require('express');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/user');
const app = express();
//ROUTES THINGY
app.use(bodyParser.json());
app.use('/user', userRoutes);
app.get('/', (req, res) => {
    res.send('NOT AUTHORIZED');
});
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
