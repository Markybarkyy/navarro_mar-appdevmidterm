const userModel = require('../models/userModel');
//REGISTRATION THINGY 
const register = (req, res) => {
    const { username, email, password } = req.body;
    const userExists = userModel.findUserByEmail(email);
    if (userExists) return res.status(400).send('User already exists.');
    const newUser = {
        id: userModel.getUsers().length + 1,
        username,
        email,
        password
    };
    //ADD A NEW USER
    userModel.addUser(newUser);
    res.status(201).send('User registered successfully.');
};

//LOGIN
const login = (req, res) => {
    const { email, password } = req.body;
    const user = userModel.findUserByEmail(email);
    if (!user || user.password !== password) return res.status(400).send('Invalid credentials.');
    res.json({ message: 'Login successful' });
};
const getProfile = (req, res) => {
    const user = userModel.getUsers().find(u => u.id === req.user.id);
    if (!user) return res.status(404).send('User not found.');

    res.json({
        id: user.id,
        username: user.username,
        email: user.email
    });
};

module.exports = { register, login, getProfile };
