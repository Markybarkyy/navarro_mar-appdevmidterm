const { readUsersFromFile, writeUsersToFile } = require('../utils/fileUtils');
//CODE BELOW GETS,FIND, AND ADD USERS
const getUsers = () => {
    return readUsersFromFile();
};
const findUserByEmail = (email) => {
    const users = getUsers();
    return users.find(u => u.email === email);
};
const addUser = (newUser) => {
    const users = getUsers();
    users.push(newUser);
    writeUsersToFile(users);
};
module.exports = {
    getUsers,
    findUserByEmail,
    addUser
};
