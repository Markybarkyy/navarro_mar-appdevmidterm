
const authMiddleware = (req, res, next) => {
    //MIDDLEWARE AUTHENTICATION
    const userId = req.header('user-id');
    if (!userId) return res.status(401).send('Access denied. No user ID provided.');

    req.user = { id: parseInt(userId) };
    next();
};
module.exports = authMiddleware;
